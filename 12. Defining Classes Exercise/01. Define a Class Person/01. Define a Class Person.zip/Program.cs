﻿using DefiningClasses;
using System;
using System.Collections.Generic;

namespace DefiningClasses
{
  public  class StartUp
    {
        static void Main(string[] args)
        {
            List<Person> people = new List<Person>();

            Person pesho = new Person();
            pesho.Name = "Pesho";
            pesho.Age = 26;
            people.Add(pesho);
            

            Person gosho = new Person();
            gosho.Name = "Gosho";
            gosho.Age = 12;
            people.Add(gosho);
            

            Person gogo = new Person();
            gogo.Name = "Gogo";
            gogo.Age = 40;
            people.Add(gogo);


            foreach (var person in people)
            {
                Console.WriteLine(person.Name+" "+person.Age);
            }
        }
    }
}
