﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            

            Person noName = new Person();
          
            Person noNameWithAge = new Person(25);
            
            Person Peshaka = new Person("Pesho", 12);
            
            
            
        }
    }
}
